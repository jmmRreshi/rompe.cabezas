var ingresarProducto;
do {
 ingresarProducto=  parseInt(prompt("1 Leche" \n +
  "2 tomate" \n +
  "3 cebolla" \n +
  "4 papas" \n +
  "5 manzanas"\n
  "6 salir"\n))
} while (ingresarProducto !==6);
